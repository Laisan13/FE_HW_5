// Составьте программу, которая выводит на экран все однозначные положительные числа в возрастающем порядке.Перед началом вывода на экран следует вывести "старт", а после окончания вывода чисел – "финиш".вывод: старт, 1, … 9, финиш)
for(let num=0; num<=10; num++){ 
    if(num==0){
        console.log('Start');
    }
    if(0<num && num!=10){
    console.log(num);
    }     
    if(num==10){
        console.log('Finish');        
    }   
}
// Составьте программу, которая выводит на экран все двузначные положительные числа, делящиеся без остатка на 3 и на 5 (начиная с наименьшего).

for(let num=1; num<=101; num++){ 
    if(num%3==0){
        console.log(num);
    }
    if(num%5==0){
    console.log(num);
    }    
}
// Подсчитать сумму всех чисел в заданном пользователем диапазоне.
let number1 = +prompt('Enter your first number');
let number2 = +prompt('Enter your second number');
let summ = 0;

if (number1>number2){
    for(let num = number2;num <= number1;num++){
        summ += num;
        if(num==number1){       
            break;            
        }
    }
}
else if(number1 < number2 ){
    for(let num = number1;num <= number2;num++){
        summ += num;
        if(num==number2){
            break;            
        }
    }
}
console.log(summ);

// Запросить у пользователя число и вывести все делители этого числа.
let number4 = +prompt('Enter your first number');
for(let num = 1;num <= number4;num++){
    if(number4%num==0){
        console.log(num);
    }   

}
// Запросить у пользователя 10 чисел и подсчитать, сколько он ввел положительных, отрицательных и нулей. При этом также посчитать, сколько четных и нечетных. Вывести статистику на экран. Учтите, что достаточно одной переменной (не 10) для ввода чисел пользователем
let number5;
let sumplus = 0;
let summinus = 0;
let summzerro = 0;
let summchet= 0;
let summnechet= 0;


for(let num=0; num <=10; num++){
    number5= +prompt('Enter your number');
    console.log(number5);
    if(number5>0){
        sumplus++;
    }
    if(number5<0){
        summinus++;
    }
    if(number5==0){
        summzerro++;
    }
    if(number5%2==0 && number5!=0){
        summchet++;
    }
    if(number5%2!=0 && number5!=0){
        summnechet++;
    }
}
console.log(`Количество положительных чисел ${sumplus}`);
console.log(`Количество отрицательных чисел чисел ${summinus}`);
console.log(`Количество четных чисел ${summchet}`);
console.log(`Количество нечетных чисел ${summnechet}`);
console.log(`Количество нулей ${summzerro}`);
